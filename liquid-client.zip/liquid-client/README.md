# Liquid Client

Launcher Android untuk Minecraft: Bedrock Edition (ARM64, Android 9+), berbasis
[LeviLauncher / LeviLaunchroid](https://github.com/LiteLDev/LeviLaunchroid) milik LeviMC
(lisensi Apache-2.0). Butuh Minecraft Bedrock asli dari Google Play.

- **Application ID:** `com.sally.liquidclient`
- **Package kode:** `org.levimc.launcher` (sengaja tidak diganti, lihat catatan)
- **Build:** GitHub Actions (`.github/workflows/build.yml`) → artifact `LiquidClient-apk`

## Build di GitHub
1. Push repo ini ke GitHub (pastikan file `liquidclient.keystore` ikut ter-push).
2. Tab **Actions** → **Build Liquid Client** → Run workflow (atau push commit).
3. Download APK dari bagian **Artifacts**. Tag `v*` otomatis membuat GitHub Release.

Secret opsional: `GOOGLE_SERVICES_JSON_BASE64` (Firebase asli, package `com.sally.liquidclient`),
`CURSEFORGE_API_KEY`.

## Catatan
- `liquidclient.keystore` adalah keystore pribadi agar tanda tangan APK selalu sama
  (bisa update tanpa uninstall). Jangan dipakai untuk Play Store; buat keystore sendiri
  dan ganti di `app/build.gradle` bila perlu.
- Package kode tetap `org.levimc.launcher` karena `libinbuiltmods.so` (binary jadi) dan
  preloader memakai nama JNI `Java_org_levimc_launcher_*`. Mengganti package kode akan
  memutus keduanya kecuali di-build ulang dari source-nya.
- Auto-update ke repo upstream dimatikan.

## Kredit
Berdasarkan LeviLaunchroid © LeviMC Team, Apache License 2.0. Lihat `LICENSE` dan `NOTICE`.
Modul `pojav_controls` memiliki lisensinya sendiri (lihat `pojav_controls/LICENSE`).
